import{A as c,e as t}from"./mermaid-parser.core.CmoLm5-z.js";export{c as ArchitectureModule,t as createArchitectureServices};
//# sourceMappingURL=architecture-O4VJ6CD3.NI1c5xHl.js.map
