import{U as a,C as n}from"./mermaid.core.B6NEFrXU.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
//# sourceMappingURL=channel.Co3GgaTo.js.map
