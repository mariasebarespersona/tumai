import{_ as s}from"./mermaid.core.B6NEFrXU.js";var t,e=(t=class{constructor(i){this.init=i,this.records=this.init()}reset(){this.records=this.init()}},s(t,"ImperativeState"),t);export{e as I};
//# sourceMappingURL=chunk-FHKO5MBM.sCha0NZK.js.map
