import{r}from"./2.Badqb4fR.js";const t=o=>r[o%r.length];export{t as g};
//# sourceMappingURL=color.Cbz7zxhf.js.map
