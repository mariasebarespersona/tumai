import{P as c,a as r}from"./mermaid-parser.core.CmoLm5-z.js";export{c as PacketModule,r as createPacketServices};
//# sourceMappingURL=packet-HUATNLJX.1BoMY2-M.js.map
