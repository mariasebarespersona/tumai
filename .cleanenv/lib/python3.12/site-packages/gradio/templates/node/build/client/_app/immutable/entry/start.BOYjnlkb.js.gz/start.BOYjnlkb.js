import{s as t}from"../chunks/client.CHduoe6c.js";export{t as start};
//# sourceMappingURL=start.BOYjnlkb.js.map
