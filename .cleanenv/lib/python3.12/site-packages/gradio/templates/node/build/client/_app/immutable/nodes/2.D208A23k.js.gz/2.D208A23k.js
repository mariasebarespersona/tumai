import{Y as e,_ as n}from"../chunks/2.Badqb4fR.js";export{e as component,n as universal};
//# sourceMappingURL=2.D208A23k.js.map
